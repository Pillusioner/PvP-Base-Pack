#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

const int FLAG_MASK_DIR = 7;
const int FLAG_INSIDE_FACE = 1 << 4;
const int FLAG_USE_TOP_COLOR = 1 << 5;
const int FLAG_EXTRA_Z = 1 << 6;
const int FLAG_EXTRA_X = 1 << 7;

layout(std140) uniform CloudInfo {
    vec4 CloudColor;
    vec3 CloudOffset;
    vec3 CellSize;
};

uniform isamplerBuffer CloudFaces;

out float vertexDistance;
out vec4 vertexColor;

// ---- direction と quadVertex から直接頂点を生成 ----
vec3 getFaceVertex(int dir, int v, bool inside) {
    // inside の場合は頂点順を反転
    int i = inside ? (3 - v) : v;

    // i = 0,1,2,3 の 4 頂点を生成
    // dir: 0=bottom,1=top,2=north,3=south,4=west,5=east
    if (dir == 0) { // bottom
        return vec3(i==0||i==1 ? 1 : 0, 0, i==0||i==3 ? 0 : 1);
    }
    if (dir == 1) { // top
        return vec3(i==2||i==3 ? 1 : 0, 1, i==1||i==2 ? 1 : 0);
    }
    if (dir == 2) { // north
        return vec3(i==2||i==3 ? 1 : 0, i==1||i==2 ? 1 : 0, 0);
    }
    if (dir == 3) { // south
        return vec3(i==0||i==1 ? 1 : 0, i==1||i==2 ? 1 : 0, 1);
    }
    if (dir == 4) { // west
        return vec3(0, i==1||i==2 ? 1 : 0, i==0||i==3 ? 1 : 0);
    }
    // east
    return vec3(1, i==1||i==2 ? 1 : 0, i==2||i==3 ? 1 : 0);
}

// ---- face color も配列不要 ----
vec4 getFaceColor(int dir, bool useTop) {
    if (useTop) return vec4(1.0, 1.0, 1.0, 1.0);

    if (dir == 0) return vec4(0.7, 0.7, 0.7, 1.0);
    if (dir == 1) return vec4(1.0, 1.0, 1.0, 1.0);
    if (dir == 2) return vec4(0.8, 0.8, 0.8, 1.0);
    if (dir == 3) return vec4(0.8, 0.8, 0.8, 1.0);
    if (dir == 4) return vec4(0.9, 0.9, 0.9, 1.0);
    return vec4(0.9, 0.9, 0.9, 1.0); // east
}

void main() {
    int v = gl_VertexID % 4;
    int index = (gl_VertexID / 4) * 3;

    int cellX = texelFetch(CloudFaces, index).r;
    int cellZ = texelFetch(CloudFaces, index + 1).r;
    int flags = texelFetch(CloudFaces, index + 2).r;

    int dir = flags & FLAG_MASK_DIR;
    bool inside = (flags & FLAG_INSIDE_FACE) != 0;
    bool useTop = (flags & FLAG_USE_TOP_COLOR) != 0;

    cellX = (cellX << 1) | ((flags & FLAG_EXTRA_X) >> 7);
    cellZ = (cellZ << 1) | ((flags & FLAG_EXTRA_Z) >> 6);

    vec3 fv = getFaceVertex(dir, v, inside);
    vec3 pos = fv * CellSize + vec3(cellX, 0, cellZ) * CellSize + CloudOffset;

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_spherical_distance(pos);
    vertexColor = getFaceColor(dir, useTop) * CloudColor;
}
