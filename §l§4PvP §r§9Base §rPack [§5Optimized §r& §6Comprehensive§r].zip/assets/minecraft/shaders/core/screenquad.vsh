#version 330 core

// 出力するテクスチャ座標
out vec2 texCoord;

void main() {
    // 頂点ID (0, 1, 2) から直接座標を生成
    // gl_VertexID & 1 は 0, 1, 0...
    // gl_VertexID & 2 は 0, 0, 2...
    // これをビットシフトと組み合わせることで、乗算命令を排除し、ALU負荷を最小化する
    float x = -1.0 + float((gl_VertexID & 1) << 2);
    float y = -1.0 + float((gl_VertexID & 2) << 1);

    // 頂点座標の設定
    gl_Position = vec4(x, y, 0.0, 1.0);

    // テクスチャ座標 (UV) の算出
    // gl_Position.xy の範囲 [-1, 1] を  に線形変換
    // 画面端 (1,1) を超える座標 (x=3, y=3) も生成されるが、
    // ラスタライザの線形補間により画面内は正確に  の範囲に収まる
    texCoord = gl_Position.xy * 0.5 + 0.5;
}

//済み