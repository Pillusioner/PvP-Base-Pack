#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:matrix.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

in vec4 texProj0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;

const vec3[] COLORS = vec3[](
    vec3(0.022087, 0.098399, 0.110818), vec3(0.011892, 0.095924, 0.089485),
    vec3(0.027636, 0.101689, 0.100326), vec3(0.046564, 0.109883, 0.114838),
    vec3(0.064901, 0.117696, 0.097189), vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380), vec3(0.097489, 0.154120, 0.091064),
    vec3(0.106152, 0.131144, 0.195191), vec3(0.097721, 0.110188, 0.187229),
    vec3(0.133516, 0.138278, 0.148582), vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696), vec3(0.047281, 0.315338, 0.321970),
    vec3(0.204675, 0.390010, 0.302066), vec3(0.080955, 0.314821, 0.661491)
);

// レイヤーごとの不変定数を事前計算 (16レイヤー分をカバー)
const float LAYER_SCALES[16] = float[](
    8.5, 8.0, 7.5, 7.0, 6.5, 6.0, 5.5, 5.0, 
    4.5, 4.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0
);
const float LAYER_TX[16] = float[](
    17.0, 8.5, 5.666666, 4.25, 3.4, 2.833333, 2.428571, 2.125,
    1.888888, 1.7, 1.545454, 1.416666, 1.307692, 1.214285, 1.133333, 1.0625
);
const float LAYER_TY_MULT[16] = float[](
    4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0,
    12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0
);
// 角度計算: radians((layer * layer * 4321.0 + layer * 9.0) * 2.0)
const float LAYER_ANGLES[16] = float[](
    151.146, 603.955, 1358.42, 2414.54, 3772.33, 5431.77, 7392.87, 9655.62,
    12220.0, 15086.1, 18253.8, 21723.2, 25494.2, 29566.9, 33941.2, 38617.2
);

out vec4 fragColor;

void main() {
    vec3 color = textureProj(Sampler0, texProj0).rgb * COLORS[0];
    
    // ベースのSCALE_TRANSLATEをテクスチャ座標に事前適用
    vec4 baseProj = vec4(
        texProj0.x * 0.5 + texProj0.w * 0.25,
        texProj0.y * 0.5 + texProj0.w * 0.25,
        texProj0.z,
        texProj0.w
    );

    for (int i = 0; i < PORTAL_LAYERS; i++) {
        vec4 proj = baseProj;
        
        // 1. 移動 (Translate) の適用
        proj.x += LAYER_TX[i] * proj.w;
        proj.y += (LAYER_TY_MULT[i] * GameTime) * proj.w; // 1.5の乗算を相殺し高速化
        
        // 2. 回転 (Rotate) と 拡大縮小 (Scale) の適用
        float angle = LAYER_ANGLES[i];
        float s = sin(angle);
        float c = cos(angle);
        float scale = LAYER_SCALES[i];
        
        float nx = (c * proj.x - s * proj.y) * scale;
        float ny = (s * proj.x + c * proj.y) * scale;
        
        proj.x = nx;
        proj.y = ny;
        
        color += textureProj(Sampler1, proj).rgb * COLORS[i + 1];
    }
    
    fragColor = apply_fog(vec4(color, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}