#version 330
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;
    if (color.a < 0.1) discard;
    // 最適化: フェード計算を排除し、アルファを直接適用
    fragColor = vec4(color.rgb * GlintAlpha, color.a);
}

//済