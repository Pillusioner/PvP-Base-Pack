#version 330

// 霧のインポートを削除
// #moj_import <minecraft:fog.glsl>

in vec4 vertexColor;

// 頂点シェーダーで霧計算を消したため、これらも不要
// in float sphericalVertexDistance;
// in float cylindricalVertexDistance;

out vec4 fragColor;

void main() {
    // アルファテスト（透明度のチェック）
    // 0.1未満のアルファ値（ほぼ透明な線）を描画から除外してGPU負荷を微減
    if (vertexColor.a < 0.1) {
        discard;
    }

    // 霧の適用を完全にカットし、色をそのまま出力
    fragColor = vertexColor;
}