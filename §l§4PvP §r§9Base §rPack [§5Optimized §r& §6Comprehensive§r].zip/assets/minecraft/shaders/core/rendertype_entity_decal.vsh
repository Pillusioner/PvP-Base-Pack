#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out vec4 vertexColor;
out vec4 overlayColor;
out vec2 texCoord0;

void main() {
    // 1. 行列演算の結合法則最適化 (Intel GPUのレジスタ節約)
    gl_Position = ProjMat * (ModelViewMat * vec4(Position, 1.0));

    // 2. 整数演算 (ビットシフト) によるライトマップ参照の高速化
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 >> 4, 0);
    
    // 3. 不要な霧(fog)計算変数を完全に排除
    overlayColor = texelFetch(Sampler1, UV1, 0);
    texCoord0 = UV0;
}