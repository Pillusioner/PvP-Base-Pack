#version 330
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;
in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    // 最適化: 除算とフォグ適用を削除し、単純な乗算のみ
    fragColor = color * vertexColor * ColorModulator;
}

//済