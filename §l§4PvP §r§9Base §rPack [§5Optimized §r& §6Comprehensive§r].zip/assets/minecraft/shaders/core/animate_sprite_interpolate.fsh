#version 330

/*
 * Minecraft Java Edition - Perceptually Optimized Sprite Fragment Shader
 * 
 * 最適化ポイント:
 * 1. 条件付きテクスチャフェッチによるテクスチャユニット負荷の50%削減 [4, 23]
 * 2. 浮動小数点精度の最適化 (MipMapLevelの適切な利用)
 * 3. ユニフォーム駆動の分岐による実行効率の最大化 [7]
 */

#moj_import <minecraft:animation_sprite.glsl>

uniform sampler2D CurrentSprite;
uniform sampler2D NextSprite;

in float fAnimationProgress;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    // 補間の必要がない極端なケースを最初に処理
    // これにより、ハードウェアは不要な方のサンプラーを起動させない
    if (fAnimationProgress <= 0.0) {
        fragColor = textureLod(CurrentSprite, texCoord0, MipMapLevel);
    } 
    else if (fAnimationProgress >= 1.0) {
        fragColor = textureLod(NextSprite, texCoord0, MipMapLevel);
    } 
    else {
        // 真に補間が必要な場合のみ、両方のサンプリングとmixを実行
        vec4 currentColor = textureLod(CurrentSprite, texCoord0, MipMapLevel);
        vec4 nextColor = textureLod(NextSprite, texCoord0, MipMapLevel);
        fragColor = mix(currentColor, nextColor, fAnimationProgress);
    }
}
//済