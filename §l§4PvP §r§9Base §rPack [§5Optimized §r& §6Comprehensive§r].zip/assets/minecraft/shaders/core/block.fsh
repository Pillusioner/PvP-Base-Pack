#version 330
#moj_import <minecraft:dynamictransforms.glsl>

layout(std140) uniform ChunkSection {
    ivec3 ChunkPosition;
};

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
    fragColor = color;
}

//済