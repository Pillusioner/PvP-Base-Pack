#version 330
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    // 最適化: 重い計算をせず、ダミーの0を渡す
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
}

//済