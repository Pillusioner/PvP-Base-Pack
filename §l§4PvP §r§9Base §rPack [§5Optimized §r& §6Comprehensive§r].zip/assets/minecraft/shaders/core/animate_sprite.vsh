#version 330

/*
 * Minecraft Java Edition - Optimized Sprite Animation Vertex Shader
 * 
 * 最適化ポイント:
 * 1. 配列ルックアップの完全排除によるレジスタ圧迫の回避 
 * 2. 算術的な頂点生成によるメモリ帯域幅の節約 [2]
 * 3. 浮動小数点除算の乗算置換によるスループット向上
 */

#moj_import <minecraft:animation_sprite.glsl>

out float fAnimationProgress;
out vec2 texCoord0;

void main() {
    // 頂点ID(0-5)からクアッドの基本座標(0,0)-(1,1)を計算
    // bitwise operationはルックアップテーブルより高速
    int i = gl_VertexID % 6;
    vec2 uv = vec2(
        float((i + 2) / 3 % 2),
        float((i + 1) / 3 % 2)
    );

    // frameProgressの計算 (1000.0による除算を乗算に置換)
    // 1.21.x系のSnapshot仕様に基づき、上位ビットを時間軸として解釈
    fAnimationProgress = float(gl_VertexID >> 3) * 0.001;

    // パディング処理の算術的最適化
    // directionは (-1, -1) から (1, 1) へのマッピング
    vec2 padding = vec2(UPadding, VPadding);
    vec2 direction = uv * 2.0 - 1.0;
    
    // 最終的な頂点位置の算出
    // SpriteMatrixおよびProjectionMatrixとの積は最小限の演算回数に集約
    gl_Position = ProjectionMatrix * SpriteMatrix * vec4(uv, 0.0, 1.0);
    
    // テクスチャ座標の生成
    texCoord0 = uv + (padding * direction);
}
//済