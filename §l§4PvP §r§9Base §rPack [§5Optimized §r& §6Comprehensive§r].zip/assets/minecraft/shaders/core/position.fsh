#version 330
#moj_import <minecraft:dynamictransforms.glsl>

out vec4 fragColor;

void main() {
    // 最適化: フォグ計算を完全にバイパス
    fragColor = ColorModulator;
}

//済